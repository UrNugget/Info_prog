/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package progettoinfo;

import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;
import java.util.ArrayList;

/**
 *
 * @author campanim
 */
public class Gestore {

    ArrayList<Studente> studenti = new ArrayList<>();
    ArrayList<Docente> docenti = new ArrayList<>();
    ArrayList<Corso> corsi = new ArrayList<>();
    ArrayList<Disciplina> discipline = new ArrayList<>();
    ArrayList<Appello> appelli = new ArrayList<>();

    public void caricaStudenti() {
        String ch = ";";
        String line;

        try ( BufferedReader br = new BufferedReader(new FileReader("studenti.csv"))) {
            br.readLine();
            while ((line = br.readLine()) != null) {
                String[] data = line.split(ch);
                String matricola = data[0];
                String nome = data[1];
                String cognome = data[2];
                Corso c = null;
                for (int i = 0; i < corsi.size(); i++) {
                    if (corsi.get(i).getCodice().equals(data[3])) {
                        c = corsi.get(i);
                    }
                }
                Studente p = new Studente(matricola, nome, cognome, c);
                studenti.add(p);
            }
        } catch (IOException e) {

        }
    }

    public void stampaStudenti() {
        for (int i = 0; i < studenti.size(); i++) {
            studenti.get(i).stampaStudente();
        }
    }

    public void aggiungiStudente(String matricola, String nome, String cognome, Corso corso) {
        Studente nuovoStudente = new Studente(matricola, nome, cognome, corso);
        studenti.add(nuovoStudente);
    }

    public void caricaDocenti() {
        String ch = ";";
        String line;

        try ( BufferedReader br = new BufferedReader(new FileReader("docenti.csv"))) {
            br.readLine();
            while ((line = br.readLine()) != null) {
                String[] data = line.split(ch);
                String matricola = data[0];
                String nome = data[1];
                String cognome = data[2];
                String disciplina = data[3];
                Docente d = new Docente(matricola, nome, cognome, disciplina);
                docenti.add(d);
            }
        } catch (IOException e) {

        }
    }

    public void stampaDocenti() {
        for (int i = 0; i < docenti.size(); i++) {
            docenti.get(i).stampaDocente();
        }
    }

    public void aggiungiDocente(String matricola, String nome, String cognome, String disciplina) {
        Docente nuovoDocente = new Docente(matricola, nome, cognome, disciplina);
        docenti.add(nuovoDocente);
    }

    public void caricaCorsi() {
        String ch = ";";
        String line;

        try ( BufferedReader br = new BufferedReader(new FileReader("corsi.csv"))) {
            br.readLine();
            while ((line = br.readLine()) != null) {
                String[] data = line.split(ch);
                String codice = data[0];
                String nome = data[1];
                int durata = Integer.parseInt(data[2]);

                Corso c = new Corso(codice, nome, durata);
                corsi.add(c);
            }
        } catch (IOException e) {

        }
    }

    public void stampaCorsi() {
        for (int i = 0; i < corsi.size(); i++) {
            corsi.get(i).stampaCorso();
        }
    }

    public void aggiungiCorso(String codice, String nome, int durata) {
        Corso nuovoCorso = new Corso(codice, nome, durata);
        corsi.add(nuovoCorso);
    }

    public void modificaCorso(String codice, String nome, int durata) {
        for (int i = 0; i < corsi.size(); i++) {
            if ((corsi.get(i).getCodice()).equals(codice)) {
                corsi.get(i).setDurata(durata);
                corsi.get(i).setNome(nome);
            }
        }
    }

    public void caricaDiscipline() {
        String ch = ";";
        String line;

        try ( BufferedReader br = new BufferedReader(new FileReader("discipline.csv"))) {
            br.readLine();
            while ((line = br.readLine()) != null) {
                String[] data = line.split(ch);
                String codice = data[0];
                String nome = data[1];
                int cfu = Integer.parseInt(data[2]);
                Corso c = null;
                for (int i = 0; i < corsi.size(); i++) {
                    if (corsi.get(i).getCodice().equals(data[3])) {
                        c = corsi.get(i);
                    }
                }
                Disciplina d = new Disciplina(codice, nome, cfu, c);
                c.addDisciplina(d);

                discipline.add(d);
            }
        } catch (IOException e) {

        }
    }

    public void stampaDiscipline() {
        for (int i = 0; i < discipline.size(); i++) {
            discipline.get(i).stampaDisciplina();
        }
    }

    public void caricaAppelli() {
        String ch = ";";
        String line;

        try ( BufferedReader br = new BufferedReader(new FileReader("appelli.csv"))) {
            br.readLine();
            while ((line = br.readLine()) != null) {
                String[] data = line.split(ch);
                String id = data[0];
                String date = data[1];
                Disciplina d = null;
                for (int i = 0; i < discipline.size(); i++) {
                    if (discipline.get(i).getCodice().equals(data[2])) {
                        d = discipline.get(i);
                    }

                }

                Appello a = new Appello(id, date, d);
                appelli.add(a);
            }
        } catch (IOException e) {

        }
    }

    public void stampaAppelli() {
        for (int i = 0; i < appelli.size(); i++) {
            appelli.get(i).stampaAppello();
        }
    }
    
    
    
    public void caricaIscrizioni() {
        String ch = ";";
        String line;

        try ( BufferedReader br = new BufferedReader(new FileReader("iscrizioni_appelli.csv"))) {
            br.readLine();
            while ((line = br.readLine()) != null) {
                String[] data = line.split(ch);
                String id = data[0];
                String matricola = data[1];
                
                //String codiceDisciplinaIscrizione 
                        
            }
        } catch (IOException e) {

        }
    }

}
