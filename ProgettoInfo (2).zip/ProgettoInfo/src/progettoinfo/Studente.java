/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package progettoinfo;

/**
 *
 * @author campanim
 */
public class Studente {

    //matricola studente, nome, cognome, corso di iscrizione
    private String matricola, nome, cognome;
    private Corso corso;

    //controlli
    public Studente(String matricola, String nome, String cognome, Corso corso) {
        this.matricola = matricola;
        this.nome = nome;
        this.cognome = cognome;
        this.corso = corso;
    }

    public String getMatricola() {
        return matricola;
    }

    public String getNome() {
        return nome;
    }

    public String getCognome() {
        return cognome;
    }

    public String getCorso() {
        return corso.getCodice();
    }

    public void stampaStudente() {
        System.out.println(matricola + ";" + nome + ";" + cognome + ";" + corso.getCodice());
    }

}
