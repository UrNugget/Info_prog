/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package progettoinfo;

/**
 *
 * @author campanim
 */
public class ProgettoInfo {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {

        Gestore g = new Gestore();
        
        g.caricaCorsi();

        g.caricaStudenti();
        g.stampaStudenti();

        System.out.println("=======");

        //g.aggiungiStudente("S006", "Leo", "Lasa", "C006");
        //g.stampaStudenti();
        g.caricaDocenti();
        g.stampaDocenti();

        //g.aggiungiDocente("45467", "Marti", "Campa", "lkj");
        //g.stampaDocenti();
        System.out.println("=======");

        g.stampaCorsi();

        System.out.println("=======");

        //g.aggiungiCorso("POI", "filosofia", 32);
        //g.stampaCorsi();
        //g.modificaCorso("C002", "P", 8);
        //g.stampaCorsi();    
        g.caricaDiscipline();
        g.stampaDiscipline();
        System.out.println("=======");
        
        g.caricaAppelli();
        g.stampaAppelli();

    }

}
