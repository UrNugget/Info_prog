/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package progettoinfo;

/**
 *
 * @author campanim
 */
public class Docente {
    //matricola docente, nome, cognome, disciplina insegnata.
    private String matricola,nome,cognome,disciplina;

    
    //controlli
    public Docente(String matricola, String nome, String cognome, String disciplina) {
        this.matricola = matricola;
        this.nome = nome;
        this.cognome = cognome;
        this.disciplina = disciplina;
    }
    
    public String getMatricola() {
        return matricola;
    }

    public String getNome() {
        return nome;
    }

    public String getCognome() {
        return cognome;
    }

    public String getDisciplina() {
        return disciplina;
    }
    
    
    public void stampaDocente(){  
        System.out.println(matricola +";"+ nome+ ";"+cognome+ ";"+disciplina);
    }
    
    
    
}
